# Pin npm packages by running ./bin/importmap
pin "@rails/ujs", to: "@rails--ujs.js", integrity: "sha384-X+EckECKMHA6j/OckXIKbV3WxrjEe2wc/emHTE7gFiwgc5N1CondIVqDLComIfkn" # @7.1.3


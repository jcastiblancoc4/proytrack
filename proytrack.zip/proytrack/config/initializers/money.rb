Money.default_currency = Money::Currency.new("COP")
